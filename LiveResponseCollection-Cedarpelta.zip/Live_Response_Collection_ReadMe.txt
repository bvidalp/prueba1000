NAME_VERSION: Live Response Collection (Cedarpelta Build - 20190905)
RELEASE DATE: 20190905
AUTHOR: Brian Moran (brian@brimorlabs.com)
TWITTER: BriMor Labs (@BriMorLabs)
Copyright: 2013-2019, Brian Moran

This file is part of the BriMor Labs Live Response Collection

The Live Response Collection is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.

Additionally, usages of all tools fall under the express license agreement stated by the tool itself.


AUTHOR NOTE: I would like to extend a very special "Thank you" to Mari DeGrazia (@maridegrazia), Adrian Leong (@Cheeky4n6Monkey), Ken Pryor (@KDPryor), Josh Madeley (@MadeleyJosh), Roberta Payne (@robertapayne_1), Brad Garnett (@brgarnett), Luca Pugliese (@lupug), Alexis Wells, Kevin Pagano (@KevinPagano3), Mark McKinnon (@markmckinnon), Tom Yarrish (@CdtDelta), Cristina Roura, Mitch Impey (@grumpy4n6), Stacey Randolph (@4n6woman), Todd Mesick (@tmesick1), Jonathon Poling (@jpoforenso), Darcy Adefehinti (@regaindata), and Kirstie Failey (@Gigs_Security) for their extensive testing and valuable feedback to make this tool what it is today!
