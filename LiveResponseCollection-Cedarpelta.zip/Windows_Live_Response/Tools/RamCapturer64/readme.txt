Belkasoft Live RAM Capturer 

Belkasoft Live RAM Capturer allows you to robustly capture running Windows computer volatile memory to a disk file.
All Windows versions from Windows XP to Windows 10 are supported. Note: please select proper product version,
according to your Windows version. If your Windows is 32 bit, use capturer from 32 bit subfolder. For 64 bit Windows,
use 64 bit capturer. You will need to run the product under Admin user as it works in Kernel mode.

The product official webpage: https://belkasoft.com/ram-capturer
You can analyze memory dumps with the help of Belkasoft Evidence Center available at https://belkasoft.com/ec

(C) Belkasoft 2002-2016